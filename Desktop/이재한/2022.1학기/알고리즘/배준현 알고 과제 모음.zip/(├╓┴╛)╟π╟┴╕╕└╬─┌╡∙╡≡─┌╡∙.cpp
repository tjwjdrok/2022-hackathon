/*#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
#include <stdlib.h>
#define MAX 26
//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.
using namespace std;

typedef struct node* node_pointer;
typedef struct node {
    char symbol; // the value of a character.
    int frequency; // the number of times the character is in the file.
    node_pointer left;
    node_pointer right;
} nodetype;

struct compare {
    bool operator()(node_pointer p, node_pointer q) {
        if (p->frequency > q->frequency)
            return true;
        return false;
    }
};

vector <node_pointer> pre;
vector <int> code;
int cnt = 0;

node_pointer create_node(char symbol, int frequency);
node_pointer Huffman(int n, priority_queue<node_pointer, vector<node_pointer>, compare>& PQ);
void encoding(node_pointer r, char ccc);
void decoding(node_pointer r, int tmp[]);
vector<int> encode;
vector<char> decode;
int main() {

    int n, frequency[MAX];
    char symbol[MAX];
    int E, D;

    node_pointer temp;
    priority_queue<node_pointer, vector<node_pointer>, compare> PQ;
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> symbol[i];
    }
    for (int i = 0; i < n; i++) {
        cin >> frequency[i];
    }
    for (int i = 0; i < n; i++) {
        PQ.push(create_node(symbol[i], frequency[i]));
    }
    temp = Huffman(n, PQ);
    cin >> E;
    for (int i = 0; i < E; i++) {
        int num;
        cin >> num;
        for (int j = 0; j < num; j++) {
            char ccc;
            cin >> ccc;
            encoding(temp, ccc);
            if (j != num - 1)
                cout << " ";
            encode.clear();
        }
        cout << endl;
    }
    cin >> D;
    for (int i = 0; i < D; i++) {
        int num;
        cin >> num;
        int tmp[100];
        for (int k = 0; k < num; k++) {
            cin >> tmp[k];
        }
        while (cnt < num) {
            decoding(temp, tmp);
        }
        cnt = 0;
        for (int j = 0; j < decode.size(); j++) {
            cout << decode.at(j);
            if (j != decode.size() - 1)
                cout << " ";
        }
        cout << endl;
        decode.clear();
    }


    return 0;
}

node_pointer create_node(char symbol, int frequency) {
    node_pointer node = (node_pointer)malloc(sizeof(nodetype));
    node->symbol = symbol;
    node->frequency = frequency;
    node->left = node->right = NULL;
    return node;
}

node_pointer Huffman(int n, priority_queue<node_pointer, vector<node_pointer>, compare>& PQ) {

    node_pointer r;

    for (int i = 1; i <= n - 1; i++) {
        node_pointer p = PQ.top();
        PQ.pop();
        node_pointer q = PQ.top();
        PQ.pop();
        node_pointer r = create_node('$', 0);
        r->left = p;
        r->right = q;
        r->frequency = p->frequency + q->frequency;
        PQ.push(r);
    }
    r = PQ.top();
    return r;
}


void encoding(node_pointer r, char ccc) {
    if (!r) {
        encode.pop_back();
        return;
    }
    encode.push_back(0);
    encoding(r->left, ccc);
    if (r->symbol == ccc) {
        for (int i = 0; i < encode.size(); i++) {
            cout << encode.at(i);
            if (i != encode.size() - 1)
                cout << " ";
        }
        return;
    }
    encode.push_back(1);
    encoding(r->right, ccc);
    encode.pop_back();
}
void decoding(node_pointer r, int tmp[]) {
    if (!r) {
        return;
    }
    if ((r->left == NULL) && (r->right == NULL)) {
        decode.push_back(r->symbol);
        return;
    }
    if (tmp[cnt] == 1) {
        cnt++;
        decoding(r->right, tmp);
    }
    else if (tmp[cnt] == 0) {
        cnt++; 
        decoding(r->left, tmp);
    }
    //cnt�� ���� �� ������ depth��!!
}*/