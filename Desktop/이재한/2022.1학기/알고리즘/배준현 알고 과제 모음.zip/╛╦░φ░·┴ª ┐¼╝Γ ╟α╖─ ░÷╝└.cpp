/*#include <iostream>
#include <vector>
#include <algorithm>
#define MAX 20
#define INF 1000000
//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.


using namespace std;
int minmult(int n, int d[], int P[][MAX], int M[][MAX]);
int minimum(int i, int j, int& minK, int M[][MAX], int d[MAX]);
void order(int i, int j, int P[][MAX]);

int d[MAX];
int M[MAX][MAX];
int P[MAX][MAX];

int main() {
	int n;
	int k;
	cin >> n;

	for (int i = 0; i <= n; i++) {
		cin >> k;
		d[i] = k;
	}

	int min_m16 = minmult(n, d, P, M);

	for (int i = 1; i < n; i++) {
		for (int j = i + 1; j <= n; j++) {
			if (j == n) {
				cout << P[i][j];//���� ���� ����!
			}
			else {
				cout << P[i][j] << " ";
			}
		}
		cout << endl;
	}

	for (int i = 1; i < n; i++) {
		for (int j = i + 1; j <= n; j++) {
			if (j == n) {
				cout << M[i][j];
			}
			else {
				cout << M[i][j] << " ";
			}
		}
		cout << endl;
	}


	order(1, n, P);
	cout << endl;

}

int minmult(int n, int d[], int P[][MAX], int M[][MAX]) {
	int i, j, k, diagonal;
	for (i = 1; i <= n; i++)
		M[i][i] = 0;
	for (diagonal = 1; diagonal <= n - 1; diagonal++)
		for (i = 1; i <= n - diagonal; i++) {
			j = i + diagonal;
			M[i][j] = minimum(i, j, k, M, d);

			P[i][j] = k;
		}
	return M[1][n];
}

int minimum(int i, int j, int& minK, int M[][MAX], int d[MAX]) {
	int minV = INF;
	for (int k = i; k <= j - 1; k++) {
		int value = M[i][k] + M[k + 1][j] + d[i - 1] * d[k] * d[j];
		if (minV > value) {
			minV = value;
			minK = k;
		}
	}
	return minV;
}

void order(int i, int j, int P[][MAX]) {
	if (i == j)
		cout << "A" << i;
	else {
		int k = P[i][j];
		cout << "(";
		order(i, k, P);
		order(k + 1, j, P);
		cout << ")";
	}
}*/