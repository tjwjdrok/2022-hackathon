/*#include <iostream>
#include <vector>
#include <algorithm>
#define MAX 128

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.


using namespace std;

const int threshold = 2;
void madd(int n, int A[][MAX], int B[][MAX], int C[][MAX]);
void msub(int n, int A[][MAX], int B[][MAX], int C[][MAX]);
void mmult(int n, int A[][MAX], int B[][MAX], int C[][MAX]);
void partition(int n, int A[][MAX],
	int A11[][MAX], int A12[][MAX], int A21[][MAX], int A22[][MAX]);
void combine(int n, int A[][MAX],
	int A11[][MAX], int A12[][MAX], int A21[][MAX], int A22[][MAX]);
void strassen(int n, int A[][MAX], int B[][MAX], int C[][MAX]);

int A[MAX][MAX];
int B[MAX][MAX];
int C[MAX][MAX];
int ccnt = 0;
unsigned findnextpowerof2(unsigned n);
int main() {
	int N;
	int change_N = 0;
	int num = 0;
	cin >> N;

	if ((N & N - 1) != 0) {
		change_N = findnextpowerof2(N);
		for (int i = 0; i < change_N; i++) {
			if (i > N - 1) {
				for (int j = N; j < change_N; j++) {
					for (int k = 0; k < change_N; k++) {
						A[j][k] = 0;
					}
				}
			}
			else {
				for (int a = 0; a < change_N; a++) {
					if (a > N - 1) {
						A[i][a] = 0;
					}
					else {
						cin >> num;
						A[i][a] = num;
					}
				}
			}
		}
		for (int i = 0; i < change_N; i++) {
			if (i > N - 1) {
				for (int j = N; j < change_N; j++) {
					for (int k = 0; k < change_N; k++) {
						B[j][k] = 0;
					}
				}
			}
			else {
				for (int a = 0; a < change_N; a++) {
					if (a > N - 1) {
						B[i][a] = 0;
					}
					else {
						cin >> num;
						B[i][a] = num;
					}
				}
			}
		}
		strassen(change_N, A, B, C);
		cout << ccnt << endl;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				cout << C[i][j]<<" ";
			}
			cout << endl;
		}
	}

	else {
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				cin >> num;
				A[i][j] = num;
			}
		}
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				cin >> num;
				B[i][j] = num;
			}
		}
		strassen(N, A, B, C);
		cout << ccnt << endl;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				cout << C[i][j]<<" ";
			}
			cout << endl;
		}
	}

	

	


}
		





unsigned findnextpowerof2(unsigned n) {
	n = n - 1;
	while (n & n - 1) {
		n = n & n - 1;
	}
	return n << 1;
}
void mmult(int n, int A[][MAX], int B[][MAX], int C[][MAX]) {
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
		{
			int tmp = 0;
			for (int k = 0; k < n; k++) {
				tmp += A[i][k] * B[k][j];
			}
			C[i][j] = tmp;
		}
}

void strassen(int n, int A[][MAX], int B[][MAX], int C[][MAX]) {
	int A11[MAX][MAX], A12[MAX][MAX], A21[MAX][MAX], A22[MAX][MAX];
	int B11[MAX][MAX], B12[MAX][MAX], B21[MAX][MAX], B22[MAX][MAX];
	int C11[MAX][MAX], C12[MAX][MAX], C21[MAX][MAX], C22[MAX][MAX];
	int M1[MAX][MAX], M2[MAX][MAX], M3[MAX][MAX], M4[MAX][MAX],
		M5[MAX][MAX], M6[MAX][MAX], M7[MAX][MAX];
	int L[MAX][MAX], R[MAX][MAX];
	ccnt++;
	
	if (n <= threshold) {
		mmult(n, A, B, C);
	}
	else {
		int m = n / 2;

		partition(n, A, A11, A12, A21, A22);
		partition(n, B, B11, B12, B21, B22);

		madd(m, A11, A22, L);
		madd(m, B11, B22, R);
		strassen(m, L, R, M1);

		madd(m, A21, A22, L);
		strassen(m, L, B11, M2);

		msub(m,B12,B22,R);
		strassen(m, A11, R, M3);

		msub(m, B21, B11, R);
		strassen(m, A22, R, M4);

		madd(m, A11, A12, L);
		strassen(m, L, B22, M5);

		msub(m, A21, A11, L);
		madd(m, B11, B12, R);
		strassen(m, L, R, M6);

		msub(m, A12, A22, L);
		madd(m, B21, B22, R);
		strassen(m, L, R, M7);

		madd(m, M1, M4, L);
		msub(m, L, M5, R);
		madd(m, R, M7, C11);

		madd(m, M3, M5, C12);
		
		madd(m, M2, M4, C21);
		
		madd(m, M1, M3, L);
		msub(m, L, M2, R);
		madd(m, R, M6, C22);
		
		combine(n, C, C11, C12, C21, C22);



	}
}

void partition(int n, int A[][MAX], int A11[][MAX], int A12[][MAX], int A21[][MAX], int A22[][MAX]) {
	int m = n / 2;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			A11[i][j] = A[i][j];
			A12[i][j] = A[i][j + m];
			A21[i][j] = A[i + m][j];
			A22[i][j] = A[i + m][j + m];
		}
	}
}

void madd(int n, int A[][MAX], int B[][MAX], int C[][MAX]) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			C[i][j] = A[i][j] + B[i][j];
		}
	}
}

void msub(int n, int A[][MAX], int B[][MAX], int C[][MAX]) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			C[i][j] = A[i][j] - B[i][j];
		}
	}
}

void combine(int n, int A[][MAX], int A11[][MAX], int A12[][MAX], int A21[][MAX], int A22[][MAX]) {
	int m = n / 2;

	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			A[i][j] = A11[i][j];
			A[i][j + m] = A12[i][j];
			A[i + m][j] = A21[i][j];
			A[i + m][j + m] = A22[i][j];

		}
	}
}*/




/*#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MALLOC(p,s)\
p = (int**)malloc(sizeof(int*) * s);\
for(int i = 0;i<s;i++){\
	p[i] = (int*)malloc(sizeof(int) * s);\
}
int** A;
int** B;
int** C;
int threshold = 4;
int cnt = 0;

void madd(int n, int** A, int** B, int** C)
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			C[i][j] = A[i][j] + B[i][j];
		}
	}
}

void msub(int n, int** A, int** B, int** C)
{
	int i, j;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			C[i][j] = A[i][j] - B[i][j];
		}
	}
}
void mmult(int n, int** A, int** B, int** C)
{
	int i, j, k;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			C[i][j] = 0;
			for (k = 0; k < n; k++)
			{
				C[i][j] += A[i][k] * B[k][j];
			}
		}
	}
}
void partition(int n, int** A, int** A11, int** A12, int** A21, int** A22)
{
	int m = n / 2;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < m; j++) {
			A11[i][j] = A[i][j];
			A12[i][j] = A[i][j + m];
			A21[i][j] = A[i + m][j];
			A22[i][j] = A[i + m][j + m];
		}
}
void combine(int n, int** C, int** C11, int** C12, int** C21, int** C22)
{
	int m = n / 2;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			C[i][j] = C11[i][j];
			C[i][j + m] = C12[i][j];
			C[i + m][j] = C21[i][j];
			C[i + m][j + m] = C22[i][j];
		}
	}
}
void printArray(int** A, int n)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			printf("%d ", A[i][j]);
		}
		printf("\n");
	}
}
void strassen(int n, int** A, int** B, int** C)
{
	cnt++;
	int** A11 = NULL, ** A12 = NULL, ** A21 = NULL, ** A22 = NULL;
	int** B11 = NULL, ** B12 = NULL, ** B21 = NULL, ** B22 = NULL;
	int** C11 = NULL, ** C12 = NULL, ** C21 = NULL, ** C22 = NULL;
	int** M1 = NULL, ** M2 = NULL, ** M3 = NULL, ** M4 = NULL, ** M5 = NULL, ** M6 = NULL, ** M7 = NULL;
	int** L = NULL, ** R = NULL;//�� or �� ���� ���ϱ� �� ���� ������ �迭 �ǹ�
	if (n <= threshold)
	{
		mmult(n, A, B, C);
	}
	else
	{
		MALLOC(A11, n); MALLOC(A12, n); MALLOC(A21, n); MALLOC(A22, n);
		MALLOC(B11, n); MALLOC(B12, n); MALLOC(B21, n); MALLOC(B22, n);
		MALLOC(C11, n); MALLOC(C12, n); MALLOC(C21, n); MALLOC(C22, n);
		MALLOC(M1, n); MALLOC(M2, n); MALLOC(M3, n); MALLOC(M4, n); MALLOC(M5, n); MALLOC(M6, n); MALLOC(M7, n);
		MALLOC(L, n); MALLOC(R, n);
		int m = n / 2;
		partition(n, A, A11, A12, A21, A22);
		partition(n, B, B11, B12, B21, B22);
		madd(m, A11, A22, L);
		madd(m, B11, B22, R);
		strassen(m, L, R, M1);//m1
		madd(m, A21, A22, L);
		strassen(m, L, B11, M2);//m2
		msub(m, B12, B22, R);
		strassen(m, A11, R, M3);//m3
		msub(m, B21, B11, R);
		strassen(m, A22, R, M4);//m4
		madd(m, A11, A12, L);
		strassen(m, L, B22, M5);//m5
		msub(m, A21, A11, L);
		madd(m, B11, B12, R);
		strassen(m, L, R, M6);//m6
		msub(m, A12, A22, L);
		madd(m, B21, B22, R);
		strassen(m, L, R, M7);//m7
		madd(m, M1, M4, L);
		msub(m, L, M5, R);
		madd(m, R, M7, C11);//C11
		madd(m, M3, M5, C12);//C12
		madd(m, M2, M4, C21);//C21
		madd(m, M1, M3, L);
		msub(m, L, M2, R);
		madd(m, R, M6, C22);//C22
		combine(n, C, C11, C12, C21, C22);
	}
}

int main(void)
{
	int size, num, i, j, k = 1, res = 0, c = 0, t = 0;
	scanf("%d", &size);
	if ((size & size - 1) == 0)
	{
		k = size;
	}
	else
	{
		k = 1 << (int)(log(size) / log(2) + 1);
	}
	MALLOC(A, k);
	MALLOC(B, k);
	MALLOC(C, k);
	for (i = 0; i < k; i++)
	{
		for (j = 0; j < k; j++)
		{
			A[i][j] = 0;
		}
	}
	for (i = 0; i < k; i++)
	{
		for (j = 0; j < k; j++)
		{
			B[i][j] = 0;
		}
	}
	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			scanf("%d", &num);
			A[i][j] = num;
		}
	}
	for (i = 0; i < size; i++)
	{
		for (j = 0; j < size; j++)
		{
			scanf("%d", &num);
			B[i][j] = num;
		}
	}
	t = size;
	size = k;
	strassen(size, A, B, C);
	printf("%d\n", cnt);
	printArray(C, t);
}*/




