/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

#include <stdlib.h>

#define MAX 257
#define INF 10000

using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

int W[MAX][MAX] = { 0, };
int P[MAX][MAX] = { 0, };
int D[MAX][MAX] = { 0, };
int n, m, u, v;

void travel(int n, int& minlength);
int count(int A);
bool isIn(int i, int A);
int minimum(int n, int i, int& minJ, int A, int W[][MAX], int D[][MAX]);
int diff(int A, int j);
void tour(int v, int A, int P[][MAX]);



int main() {
	cin >> n;
	cin >> m;
	int num = 0;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			W[i][j] = INF;
		}
	}

	for (int i = 1; i <= m; i++) {
		cin >> u;
		cin >> v;
		cin >> num;
		W[u][v] = num;
	}
	int minlength = 0;
	travel(n, minlength);


	cout << "1" << " ";
	tour(1, (pow(2, n - 1) - 1), P);
	if (minlength < INF) {
		cout << " " << minlength;
	}
	cout << endl;
	
	
	for (int i = 1; i <= n; i++) {
		for (int j = 0; j < pow(2, n - 1); j++) {
			if (j == (pow(2, n - 1) - 1)) {
				cout << P[i][j] << endl;
			}
			else {
				cout << P[i][j] << " ";
			}
		}
	}

}

void travel(int n, int& minlength) {
	
	int j = 0;
	int subset_size = pow(2, n - 1);
	for (int i = 2; i <= n; i++)
		D[i][0] = W[i][1];
	for (int k = 1; k <= n - 2; k++)
		for (int A = 0; A<subset_size; A++)
			if (count(A) == k) {
				for (int i = 2; i <= n; i++) {
					if (!isIn(i, A)) {
						D[i][A] = minimum(n, i, j, A, W, D);
						P[i][A] = j;
					}
				}
			}
	int A = subset_size - 1;
	D[1][A] = minimum(n, 1, j, A, W, D);
		
	P[1][A] = j;
	minlength = D[1][A];

	//for (int i = 2; i <= n; i++) { //D�迭����ϴ� �ڵ� ���� 2�����, ���� 0������ ����.
		//for (int j = 0; j <= A; j++) {
			//cout << D[i][j] << " ";
		//}
		//cout << endl;
	//}
}

int count(int A) {//A�� ������ ����
	int cnt = 0;
	for (; A != 0; A >>= 1)
		if (A & 1) cnt++;
	return cnt;
}

bool isIn(int i, int A) {//A�� ���ϴ��� Ȯ��
	return (A & (1 << (i - 2))) != 0;
}

int minimum(int n, int i, int& minJ, int A, int W[][MAX], int D[][MAX]) {
	int minV = INF;
	for (int j = 2; j <= n; j++) {
		if (!isIn(j, A)) continue;
		int value = W[i][j] + D[j][diff(A, j)];
		if (minV > value) {
			minV = value;
			minJ = j;
		}
	}
	return minV;
}

int diff(int A, int j) {//������ ���ϱ�
	return (A & ~(1 << (j - 2)));
}


void tour(int v, int A, int P[][MAX]) {
	if (A == 0)
		cout << "1" ;
	else {
		cout << P[v][A] << " ";
		tour(P[v][A], diff(A, P[v][A]), P);
	}
}*/




//������� �ڵ嵵��



/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <math.h>
#include <stdlib.h>


#define MAX 257
#define INF 10000

using namespace std;

int minimum(int n, int i, int& minJ, int A, int W[][MAX], int D[][MAX]);
void travel(int n, int& minlength);
void tour(int v, int A, int P[][MAX]);
int count(int A);
bool isIn(int i, int A);
int diff(int A, int j);

int W[MAX][MAX] = { 0, }, P[MAX][MAX] = { 0, }, D[MAX][MAX] = { 0, };

int main() {
	int n, m, u, v, minlength = 0;

	cin >> n >> m;

	int size = pow(2, n - 1);

	for (int i = 0; i < m; i++) {
		cin >> u >> v;
		cin >> W[u][v];
	}

	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			if (i != j && W[i][j] == 0)
				W[i][j] = INF;

	travel(n, minlength);

	cout << "1" << " ";
	tour(1, (pow(2, n - 1) - 1), P);
	if (minlength < INF) {
		cout << " " << minlength;
	}
	cout << endl;

	for (int i = 1; i <= n; i++) {
		for (int j = 0; j < pow(2, n - 1); j++) {
			if (j == (pow(2, n - 1) - 1)) {
				cout << P[i][j] << endl;
			}
			else {
				cout << P[i][j] << " ";
			}
		}
	}

	return 0;
}

int count(int A) {
	int cnt = 0;
	for (; A != 0; A >>= 1)
		if (A & 1) cnt++;
	return cnt;
}

bool isIn(int i, int A) {
	return (A & (1 << (i - 2))) != 0;
}

int diff(int A, int j) {
	return (A & ~(1 << (j - 2)));
}

int minimum(int n, int i, int& minJ, int A, int W[][MAX], int D[][MAX]) {
	int minV = INF;
	for (int j = 2; j <= n; j++) {
		if (!isIn(j, A)) continue;
		int value = W[i][j] + D[j][diff(A, j)];
		if (minV > value) {
			minV = value;
			minJ = j;
		}
	}
	return minV;
}

void travel(int n, int& minlength) {
	int i, j = 0, k;
	int subset_size = pow(2, n - 1);

	for (i = 2; i <= n; i++)
		D[i][0] = W[i][1];
	for (k = 1; k <= n - 2; k++)
		for (int A = 0; A < subset_size; A++) {
			if (count(A) != k) continue;
			for (i = 2; i <= n; i++) {
				if (isIn(i, A)) continue;
				D[i][A] = minimum(n, i, j, A, W, D);
				P[i][A] = j;
			}
		}
	D[1][subset_size - 1] = minimum(n, 1, j, subset_size - 1, W, D);
	P[1][subset_size - 1] = j;
	minlength = D[1][subset_size - 1];
}

void tour(int v, int A, int P[][MAX]) {
	if (A == 0)
		cout << "1";
	else {
		cout << P[v][A] << " ";
		tour(P[v][A], diff(A, P[v][A]), P);
	}
}*/
