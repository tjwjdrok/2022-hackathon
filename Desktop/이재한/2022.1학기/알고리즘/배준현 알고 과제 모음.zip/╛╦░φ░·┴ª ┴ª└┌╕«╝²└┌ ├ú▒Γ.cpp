/*#include <iostream>
#include <vector>
#include <algorithm>
//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.
using namespace std;

int binarySearch(vector<int> S, int low, int high);
int main(){
   vector <int> S;
   int T,num;
   int n;

   cin >> T;

   for (int i = 0; i < T; i++){
      cin >> n;
      for (int k=0 ; k < n; k++){
         cin >> num;
         S.push_back(num);
      }
      if (binarySearch(S, 0, n- 1) == -1) {
          cout << "NONE" << endl;
      }
      else if (binarySearch(S, 0, n- 1) != -1) {
          cout << binarySearch(S, 0, n-1) << endl;
      }
     
      S.clear();
   }
}

int binarySearch(vector<int> S, int low, int high)
{
    int mid=0;

    if (low > high) {
        return -1;
    }
    else {
        mid = (low + high) / 2;
        if (mid == S[mid]) {
            return mid;
        }
        else if (mid < S[mid]) {
            return binarySearch(S, low, mid-1);
        }
        else {
            return binarySearch(S, mid+1, high);
        }
    }
}*/