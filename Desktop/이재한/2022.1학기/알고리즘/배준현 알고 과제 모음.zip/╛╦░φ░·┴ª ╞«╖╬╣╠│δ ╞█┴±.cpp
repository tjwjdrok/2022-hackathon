//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.
/*#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
#define MAX 1024

using namespace std;
int board[MAX][MAX];
int ccount = 0;

bool check(int m, int x, int y);
void tromino(int m, int x, int y);


int main() {
	int n;
	cin >> n;
	int m = (int)pow(2, n);
	int i, j;
	cin >> i;
	cin >> j;
	board[i][j] = -1;
	tromino(m, 0, 0);
	board[i][j] = 0;
	for (int i = 0; i < m; i++) {
		for (int j = 0; j < m; j++) {
			printf("%d ", board[i][j]);
		}
		cout << endl;
	}
}


bool check(int m, int x, int y) {
	for (int i = x; i < x + m; i++) {
		for (int j = y; j < y + m; j++) {
			if (board[i][j] != 0)
				return false;

		}
	}
	return true;
}


void tromino(int m, int x, int y) {
	ccount++;
	int mid = m / 2;
	if (check(mid, x, y))
		board[x + mid - 1][y + mid - 1] = ccount;
	if (check(mid, x, y + mid))
		board[x + mid - 1][y + mid] = ccount;
	if (check(mid, x + mid, y))
		board[x + mid][y + mid - 1] = ccount;
	if (check(mid, x + mid, y + mid))
		board[x + mid][y + mid] = ccount;
	if (m == 2)
		return;

	tromino(mid, x, y);
	tromino(mid, x, y + mid);
	tromino(mid, x + mid, y);
	tromino(mid, x + mid, y + mid);
}*/



