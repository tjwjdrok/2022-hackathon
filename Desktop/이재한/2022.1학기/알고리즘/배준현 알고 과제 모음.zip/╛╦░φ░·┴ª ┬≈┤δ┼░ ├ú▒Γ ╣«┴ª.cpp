/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#include <map>
#define MAX 20

using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.


int tournament(int low, int high, int S[MAX]);
void find_largest(int n, int S[MAX], int& large);
int large = 0;
int sec_large = 0;
int S[MAX];
int loserlist[MAX];
int cnt = 0;
int n;

int main() {
	cin >> n;
	int num;
	for (int i = 1; i <= n; i++) {
		cin >> S[i];
		
	}
	find_largest(n, S, large);
	
	tournament(1, n, S);

	for (int i = 0; i < cnt; i++) {
		if (i == cnt - 1) {
			cout << loserlist[i] << endl;
		}
		else {
			cout << loserlist[i] << " ";
		}
		
	}
	find_largest(cnt, loserlist, sec_large);
	cout << sec_large << endl;

	
	

}


int tournament(int low, int high, int S[MAX]) {
	int mid = 0;
	int left = 0;
	int right = 0;
	int winner = 0;
	int loser = 0;

	if (low == high) {
		return S[low];
	}
	else {
		mid = (low + high) / 2;
		left = tournament(low, mid, S);
		right = tournament(mid + 1, high, S);
		winner = left;
		loser = right;
		if(winner==large||loser==large){
			if (winner < loser) {
				loserlist[cnt] = winner;
				cnt++;
			}
			else {
				loserlist[cnt] = loser;
				cnt++;
			}
		}
		
		if (winner < loser) {
			
			swap(winner, loser);
			
		}
		return winner;
	
	}
}

void find_largest(int n, int S[MAX], int& large) {
	int i;
	large = S[1];
	for (i = 2; i <= n; i++)
		if (S[i] > large)
			large = S[i];
}*/