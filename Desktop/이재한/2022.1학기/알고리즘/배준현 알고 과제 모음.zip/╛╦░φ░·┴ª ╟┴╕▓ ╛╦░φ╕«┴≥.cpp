﻿/*#include <iostream>
#include <vector>
#include <algorithm>


#define MAX 20
#define INF 100000

using namespace std;


//[2018111886] [강창민] 저는 이 소스 코드를 다른 소스 코드를 복사하지 않고 직접 작성하였습니다.



typedef struct edge* edge_pointer;

typedef struct edge {
	int u;
	int v;
	int weight;
} edgetype;

typedef vector<edge_pointer> set_of_edges;


void prim(int n, int W[][MAX], set_of_edges& F,int nearest[MAX], int distance[MAX]);



int main() {
	int N, M, a, b, cost;
	set_of_edges F;
	int W[MAX][MAX];
	int nearest[MAX];
	int distance[MAX];
	cin >> N;
	cin >> M;

	for (int i = 1; i <= N; i++) {
		for (int j = 1; j <= N; j++) {
			if (i == j) {
				W[i][j] = 0;
			}
			else {
				W[i][j] = INF;
			}
		}
	}
	

	for (int i = 0; i < M; i++) {
		cin >> a;
		cin >> b;
		cin >> cost;
		W[a][b] = cost;
		W[b][a] = cost;
	}

	prim(N, W, F, nearest, distance);
	for (int i = 0; i < N - 1; i++) {
		cout << F[i]->u << " ";
		cout << F[i]->v << " ";
		cout << F[i]->weight;
		cout << endl;
	}
	
}




void prim(int n, int W[][MAX], set_of_edges& F,int nearest[MAX],int distance[MAX]) {
	int i, vnear = 0 , min;
	edge_pointer e;
	F = { 0 };
	F.clear(); 
	for (i = 2; i <= n; i++) {
		nearest[i] = 1;
		distance[i] = W[1][i];
	}

	for (int k = 1; k < n; k++) {
		min = INF;
		for (i = 2; i <= n; i++)
			if ( distance[i] >= 0 && distance[i] < min ) {
				min = distance[i];
				vnear = i;
			}

		e = (edge_pointer)malloc(sizeof(edgetype));
		if (e != NULL) {
			e->u = vnear;
			e->v = nearest[vnear];
			e->weight = distance[vnear];
			F.push_back(e);
		}

		distance[vnear] = -1;

		for (i = 2; i <= n; i++)
			if (W[i][vnear] < distance[i]) {
				distance[i] = W[i][vnear];
				nearest[i] = vnear;
			}

		for (int i = 2; i <= n; i++) {	
			if (i == n) {
				cout << nearest[i];
			}
			else {
				cout << nearest[i] << " ";
			}
			
		}
		cout << endl;
		for (int i = 2; i <= n; i++) {
			if (i == n) {
				if (distance[i] >= INF) {
					cout << "INF" ;
				}
				else {
					cout << distance[i] ;
				}
			}

			else if (distance[i] >= INF) {
				cout << "INF" << " ";
			}
			else {
				cout << distance[i] << " ";
			}
		}
		cout << endl;
	}
}*/
