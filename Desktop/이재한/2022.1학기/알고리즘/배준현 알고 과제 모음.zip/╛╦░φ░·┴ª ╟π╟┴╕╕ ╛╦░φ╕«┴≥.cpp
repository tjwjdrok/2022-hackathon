/*#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#define MAX 26
using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.


typedef struct node* node_pointer;
typedef struct node {
	char symbol; // the value of a character.
	int frequency; // the number of times the character is in the file.
	node_pointer left;
	node_pointer right;
} nodetype;

struct compare {
	bool operator()(node_pointer p, node_pointer q) {
		if (p->frequency > q->frequency)
			return true;
		return false;
	}
};


priority_queue<node_pointer, vector<node_pointer>, compare> PQ;
node_pointer create_node(char symbol, int frequency);
void preorder(node_pointer root);
void inorder(node_pointer root);
node_pointer huffman();

int n;
int frequency[MAX];
char symbol[MAX];

vector<node_pointer> pre;
vector<node_pointer> ino;


int main() {
	node_pointer root = (node_pointer)malloc(sizeof(nodetype));
	cin >> n;
	
	for (int i = 0; i < n; i++) {
		cin >> symbol[i];
	}
	for (int i = 0; i < n; i++) {
		cin >> frequency[i];
	}

	//������������ �����ϴ� �ڵ�
	int min;
	for (int i = 0; i < n; i++) {
		min = i;
		for (int j = i + 1; j < n; j++) {
			if (frequency[min] > frequency[j]) {
				min = j;
			}
		}
		if (i != min) {
			int temp1;
			char temp2;
			temp1 = frequency[i];
			frequency[i] = frequency[min];
			frequency[min] = temp1;

			temp2 = symbol[i];
			symbol[i] = symbol[min];
			symbol[min] = temp2;
		}
	}

	root = huffman();
	preorder(root);
	for (int i = 0; i < pre.size(); i++) {
		if (i == pre.size() - 1) {
			if (pre[i]->symbol == '$') {
				cout << pre[i]->frequency ;
			}
			else if(pre[i]->symbol != '$'){
				cout << pre[i]->symbol ;
			}
			break;
		}
		if (pre[i]->symbol == '$') {
			cout << pre[i]->frequency << " ";
		}
		else if(pre[i]->symbol != '$'){
			cout << pre[i]->symbol << " ";
		}
	}
	cout << endl;
	inorder(root);
	for (int i = 0; i < ino.size(); i++) {
		if (i == ino.size() - 1) {
			if (ino[i]->symbol == '$') {
				cout << ino[i]->frequency;
			}
			else if(ino[i]->symbol != '$'){
				cout << ino[i]->symbol;
			}
			break;
		}
		if (ino[i]->symbol == '$') {
			cout << ino[i]->frequency << " ";
		}
		else if(ino[i]->symbol != '$'){
			cout << ino[i]->symbol << " ";
		}
	}
	cout << endl;
}


node_pointer create_node(char symbol, int frequency) {
	node_pointer node = (node_pointer)malloc(sizeof(nodetype));
	if (node != NULL) {
		node->symbol = symbol;
		node->frequency = frequency;
		node->left = NULL;
		node->right = NULL;
	}
	return node;
}

node_pointer huffman() {
	node_pointer root = (node_pointer)malloc(sizeof(nodetype));
	for (int i = 0; i < n; i++) {
		PQ.push(create_node(symbol[i], frequency[i]));
	}

	for (int i = 0; i < n - 1; i++) {
		node_pointer p = PQ.top();
		PQ.pop();
		node_pointer q = PQ.top();
		PQ.pop();
		

		node_pointer r = (node_pointer)malloc(sizeof(nodetype));
		if (r != NULL) {
			r->symbol = '$';
			r->left = p;
			r->right = q;
			r->frequency = p->frequency + q->frequency;
			PQ.push(r);
		}
		
	}

	return root=PQ.top();

}


void preorder(node_pointer root) {
	if (root) {
		if (root->symbol != '$') {
			pre.push_back(root);
		}
		else if(root->symbol == '$'){
			pre.push_back(root);
		}
		preorder(root->left);
		preorder(root->right);
	}
}

void inorder(node_pointer root) {
	if (root) {
		inorder(root->left);
		if (root->symbol != '$') {
			ino.push_back(root);
		}
		else if (root->symbol == '$') {
			ino.push_back(root);
		}
		inorder(root->right);
	}
}*/


