/*#include <iostream>
#include <vector>
#include <algorithm>
#define MAX 10000
//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.
using namespace std;
int table[MAX][MAX];
int smallmid(int a, int b, int key, int n, int m);
int bigmid(int a, int b, int key, int n, int m);
int main() {

    int n, m, i, j;
    int T;
    int key = 0;

    cin >> n;
    cin >> m;

    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            cin >> table[i][j];
        }
    }

    cin >> T;
    for (int k = 0; k < T; k++) {
        cin >> key;
        int midx, midy;
        int num = 0;
        midx = n / 2;
        midy = m / 2;
        if (key == table[midx][midy]) {
            printf("%d %d\n", midx, midy);
        }
        else if (key < table[midx][midy]) {
            num = smallmid(0, 0, key, n, m);
            if (num == -1) {
                cout << "NONE" << endl;
            }
        }
        else {
            num = bigmid(n - 1, m - 1, key, n, m);
            if (num == -1) {
                cout << "NONE" << endl;
            }
        }
    }

}

int smallmid(int a, int b, int key, int n, int m) {
    for (int i = 0; i < m; i++) {
        if (key == table[a][i]) {
            printf("%d %d\n", a, i);
            return 1;
        }
    }
    if (a == n - 1) {
        return -1;
    }
    else {
        smallmid(a + 1, b, key, n, m);
    }
}

int bigmid(int a, int b, int key, int n, int m) {
    for (int i = b; i >= 0; i--) {
        if (key == table[a][i]) {
            printf("%d %d\n", a, i);
            return 1;
        }
    }
    if (a == 0) {
        return -1;
    }
    else {
        bigmid(a - 1, b, key, n, m);
    }
}*/


