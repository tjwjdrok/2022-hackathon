/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#include <map>
#define MAX 100

using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

typedef struct item {
	int index;
	int weight;
} item_t;

struct compare {
	bool operator()(item_t p, item_t q) {
		if (p.weight < q.weight)
			return true;
		return false;
	}
};

typedef priority_queue<item_t, vector<item_t>, compare> pqueue_t;
typedef vector<item_t> bin_t;
void binpack(int W, int n, pqueue_t PQ, vector<bin_t>& bins);


int n;
int W;
int s[MAX];
bool ableToFit(bin_t bin_ptr, item_t item, int W);


int main() {
	pqueue_t PQ;

	cin >> n;
	cin >> W;

	for (int i = 1; i <= n; i++) {
		item_t item;
		item.index = i;
		cin >> item.weight;
		PQ.push(item);
	}
	vector<bin_t> bins;//�ڽ��� �� ��!
	binpack(W, n, PQ, bins);
	cout << bins.size() << endl;

	for (int i = 0; i < bins.size(); i++) {
		for (int j = 0; j < bins[i].size(); j++) {
			if (j == bins[i].size() - 1) {
				cout << bins[i][j].weight << endl;
			}
			else {
				cout << bins[i][j].weight << " ";
			}
			
		}
			
	}
}

void binpack(int W, int n, pqueue_t PQ, vector<bin_t>& bins) {
	while (!PQ.empty()) {
		item_t item = PQ.top(); 
		PQ.pop();
		bool isPacked = false;
		vector<bin_t>::iterator bin_ptr = bins.begin();
		for (; !isPacked && bin_ptr != bins.end(); bin_ptr++) {//ù��° �ڽ����� ���� ����ϴ°�!
			if (ableToFit(*bin_ptr, item, W)) {
				bin_ptr->push_back(item);
				isPacked = true;
			}
		}
		if (!isPacked) {//���ο� �ڽ� ����°�!
			bin_t bin;
			bin.push_back(item);
			bins.push_back(bin);
		}
	}
}

bool ableToFit(bin_t bin_ptr, item_t item, int W) {
	int weightsum = 0;
	for (int i = 0; i < bin_ptr.size(); i++) {
		weightsum += bin_ptr[i].weight;
	}
	if (weightsum + item.weight <= W) {
		return true;
	}
	else {
		return false;
	}
}*/

