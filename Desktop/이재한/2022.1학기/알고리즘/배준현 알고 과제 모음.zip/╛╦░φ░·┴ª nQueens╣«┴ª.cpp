/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#define MAX 10
using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

void queens(int i);
bool promising(int i);

int col[MAX];
int list[MAX] = {0};
int n;
int list_idx = 0;


int main() {
	cin >> n;

	int T;
	int find;
	cin >> T;
	queens(0);

	for (int s = 0; s < T; s++) {
		cin >> find;
		for (int t = 0; t < list_idx; t++) {
			if (find == list[t]) {
				cout << "YES" << endl;
				break;
			}
			else if(t==list_idx-1){
				cout << "NO" << endl;
			}
		}

	}
	
}

void queens(int i) {
	int j;
	if (promising(i)) {
		if (i == n) {
			for (int i = 1; i <= n; i++) {
				list[list_idx] = list[list_idx] + col[i] * (int)pow(10, n - i);
			}
			list_idx++;
		}

		else
			for (j = 1; j <= n; j++) {
				col[i + 1] = j;
				queens(i + 1);
			}
	}
}

bool promising(int i) {
	int k = 1;
	bool flag = true;
	while (k < i && flag) {
		if ((col[i] == col[k]) || (abs(col[i] - col[k]) == i - k))
			flag = false;
		k++;
	}
	return flag;
}*/