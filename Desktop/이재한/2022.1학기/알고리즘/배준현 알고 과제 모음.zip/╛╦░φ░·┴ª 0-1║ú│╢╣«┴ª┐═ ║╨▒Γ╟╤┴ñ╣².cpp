/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#include <map>
#define MAX 256
#define TRUE 1
#define FALSE 0


using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.
typedef struct node* node_pointer;
typedef struct node {
    int level; // the node's level in the state space tree
    int weight;
    int profit;
    float bound;
} nodetype;


struct compare {
    bool operator()(node_pointer u, node_pointer v) {
        if (u->bound < v->bound)
            return true;
        return false;
    }
};
typedef priority_queue<node_pointer, vector<node_pointer>, compare> priority_queue_of_node;

//void breadth_first_branch_and_bound(state_space_tree T, int& best);
void knapsack5();
float bound(node_pointer u);
node_pointer create_node(int level, int weight, int profit);
int w[MAX], p[MAX], n, W, maxprofit = 0;
int maxweight = 0;
float maxbound = 0;
int cnt = 0;

int main() {
    int T;

    cin >> n;

    for (int i = 1; i <= n; i++)
        cin >> w[i];
    for (int i = 1; i <= n; i++)
        cin >> p[i];

    for (int i = 1; i <= n; i++)
        for (int j = i; j <= n; j++)
            if (p[i] / w[i] < p[j] / w[j]) {
                swap(p[i], p[j]);
                swap(w[i], w[j]);
            }

    cin >> T;

    for (int i = 0; i < T; i++) {
        cin >> W;
        knapsack5();
        cout << maxprofit << " ";
        cout << maxweight << " ";
        cout << maxbound << " ";
        cout << cnt << endl;
        cnt = 0;
    }
}


void knapsack5() {
    priority_queue_of_node Q;
    node_pointer u, v;
    maxprofit = 0;
    maxweight = 0;
    maxbound = 0;

    Q.push(create_node(0, 0, 0));
    cnt++;
    while (!Q.empty()) {
        v = Q.top();
        Q.pop();
        if (v->bound > maxprofit) {
            u = create_node(v->level + 1,//(1,1)��� ����
                v->weight + w[v->level + 1],
                v->profit + p[v->level + 1]);
            if (u->weight <= W && u->profit > maxprofit) {
                maxprofit = u->profit;
                maxweight = u->weight;
                maxbound = u->bound;
            }
            if (bound(u) > maxprofit) {
                
                Q.push(u);
                cnt++;
            }
            u = create_node(v->level + 1, v->weight, v->profit);//(1,2)��� ����
            if (bound(u) > maxprofit) {
                Q.push(u);
                cnt++;
            }
        }
    }
}

float bound(node_pointer u) {// �Ѿ�� ������ ����� �ٿ�� ������ִ� �Լ� 
    int j, k;
    int totweight = 0;
    float result;
    if (u->weight >= W)
        return 0;
    else {
        result = u->profit;
        j = u->level + 1;
        totweight = u->weight;
        while (j <= n && totweight + w[j] <= W) {
            totweight += w[j];
            result += p[j];
            j++;
        }
        k = j;
        if (k <= n)
            result += (W - totweight) * ((float)p[k] / w[k]);
        return result;
    }
}

node_pointer create_node(int level, int weight, int profit) {
    node_pointer node = (node_pointer)malloc(sizeof(nodetype));

    if (node != NULL) {
        node->level = level;
        node->weight = weight;
        node->profit = profit;
        node->bound = bound(node);
        return node;
    }
}*/


