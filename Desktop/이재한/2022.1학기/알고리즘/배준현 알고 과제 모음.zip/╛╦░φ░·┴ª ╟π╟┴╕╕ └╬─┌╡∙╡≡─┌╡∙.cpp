/*#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stdlib.h>
#define MAX 26
using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

typedef struct node* node_pointer;
typedef struct node {
	char symbol; // the value of a character.
	int frequency; // the number of times the character is in the file.
	node_pointer left;
	node_pointer right;
} nodetype;

struct compare {
	bool operator()(node_pointer p, node_pointer q) {
		if (p->frequency > q->frequency)
			return true;
		return false;
	}
};


priority_queue<node_pointer, vector<node_pointer>, compare> PQ;
node_pointer create_node(char symbol, int frequency);
//void preorder(node_pointer root);
//void inorder(node_pointer root);
node_pointer huffman();

int n;
int frequency[MAX];
char symbol[MAX];

//vector<node_pointer> pre;
//vector<node_pointer> ino;
void encoding(node_pointer root, char code);
void decoding(node_pointer root, int tmp[]);
vector<int> encode;
vector<char> decode;
int cnt = 0;
int main() {

	node_pointer root = (node_pointer)malloc(sizeof(nodetype));
	cin >> n;

	for (int i = 0; i < n; i++) {
		cin >> symbol[i];
	}
	for (int i = 0; i < n; i++) {
		cin >> frequency[i];
	}

	int min;
	for (int i = 0; i < n; i++) {
		min = i;
		for (int j = i + 1; j < n; j++) {
			if (frequency[min] > frequency[j]) {
				min = j;
			}
		}
		if (i != min) {
			int temp1;
			char temp2;
			temp1 = frequency[i];
			frequency[i] = frequency[min];
			frequency[min] = temp1;

			temp2 = symbol[i];
			symbol[i] = symbol[min];
			symbol[min] = temp2;
		}
	}

	root = huffman();

	//���ڵ��ϴ� �κ�
	int E, k;
	cin >> E;
	node_pointer enen;
	enen = root;
	for (int i = 0; i < E; i++) {
		cin >> k;
		for (int j = 0; j < k; j++) {
			char code;
			cin >> code;
			encoding(enen, code);
			if (j != k - 1) {
				cout << " ";
			}
			encode.clear();
		}
		cout << endl;
	}

	//���ڵ� �ϴ� �κ�
	int D, l;
	cin >> D;
	for (int i = 0; i < D; i++) {
		cin >> l;
		int tmp[100];
		for (int j = 0; j < l; j++) {
			cin >> tmp[j];
		}
		while (cnt < l) {
			decoding(root, tmp);
		}

		cnt = 0;
		for (int j = 0; j < decode.size(); j++) {
			cout << decode.at(j);
			if (j != decode.size() - 1) {
				cout << " ";
			}
		}
		if (i != D-1) {
			cout << endl;
		}
		decode.clear();
	}
}


node_pointer create_node(char symbol, int frequency) {
	node_pointer node = (node_pointer)malloc(sizeof(nodetype));
	if (node != NULL) {
		node->symbol = symbol;
		node->frequency = frequency;
		node->left = NULL;
		node->right = NULL;
	}
	return node;
}

node_pointer huffman() {
	node_pointer root = (node_pointer)malloc(sizeof(nodetype));
	for (int i = 0; i < n; i++) {
		PQ.push(create_node(symbol[i], frequency[i]));
	}

	for (int i = 0; i < n - 1; i++) {
		node_pointer p = PQ.top();
		PQ.pop();
		node_pointer q = PQ.top();
		PQ.pop();


		node_pointer r = (node_pointer)malloc(sizeof(nodetype));
		if (r != NULL) {
			r->symbol = '$';
			r->left = p;
			r->right = q;
			r->frequency = p->frequency + q->frequency;
			PQ.push(r);
		}

	}

	return root = PQ.top();

}


void encoding(node_pointer root, char code) {

	node_pointer tmp = root;
	if (!tmp) {
		encode.pop_back();
		return;
	}

	encode.push_back(0);
	encoding(tmp->left, code);
	if (tmp->symbol == code) {
		for (int i = 0; i < encode.size(); i++) {
			cout << encode.at(i);
			if (i != encode.size()) {
				cout << " ";
			}
		}
		return;
	}
	encode.push_back(1);
	encoding(tmp->right, code);
	encode.pop_back();
}

void decoding(node_pointer root, int tmp[]) {
	if (!root) {
		return;
	}

	if ((root->left == NULL) && (root->right == NULL)) {
		decode.push_back(root->symbol);
		return;
	}

	if (tmp[cnt] == 1) {
		cnt++;
		decoding(root->right, tmp);
	}
	else if (tmp[cnt] == 0) {
		cnt++;
		decoding(root->left, tmp);
	}
}*/


