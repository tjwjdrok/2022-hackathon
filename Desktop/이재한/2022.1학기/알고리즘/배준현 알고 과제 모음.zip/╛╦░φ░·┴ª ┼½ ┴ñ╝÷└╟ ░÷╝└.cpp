/*#include <iostream>
#include <vector>
#include <algorithm>
#include <string.h>
#define MAX 256
#define BASE 10
#define threshold 1

int ccnt = 0;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.
using namespace std;

typedef struct large_integer {
	int sign;
	int len;
	int digits[MAX];
}large_integer;

void create_largeint(large_integer& u, char* str);
int compare_by_abs(large_integer u, large_integer v);
large_integer lsum(large_integer u, large_integer v);
large_integer ldiff(large_integer u, large_integer v);
large_integer ladd(large_integer& u, large_integer& v);
large_integer lsub(large_integer u, large_integer v);
large_integer lmult(large_integer u, large_integer v);
large_integer pow_by_exp(large_integer u, int m);
large_integer div_by_exp(large_integer u, int m);
large_integer rem_by_exp(large_integer u, int m);
large_integer prod2(large_integer u, large_integer v);

int main() {
	int T;
	large_integer u, v, total;
	char a[MAX], b[MAX];
	cin >> T;

	for (int i = 0; i < T; i++) {
		cin >> a;
		cin >> b;
		create_largeint(u, a);
		create_largeint(v, b);
		total = prod2(u, v);
		cout << ccnt << " ";
		for (int i = total.len - 1; i >= 0; i--) {
			cout << total.digits[i];
		}
		cout << endl;
	}
}

void create_largeint(large_integer& u, char* str) {

	int index = 0;
	for (int i = strlen(str) - 1; i >= 0; i--) {
		u.digits[i] = str[index] - '0';
		index++;
	}
	u.sign = 0;
	u.len = index;
}

large_integer ladd(large_integer& u, large_integer& v) {
	large_integer new_r;
	if (u.sign == v.sign) {
		new_r = lsum(u, v);
		new_r.sign = u.sign;
	}
	else {
		switch (compare_by_abs(u, v)) {

		case 1:

			new_r = ldiff(u, v);
			new_r.sign = u.sign;
			break;
		case -1:

			new_r = ldiff(v, u);
			new_r.sign = v.sign;
			break;
		case 0:

			new_r.sign = new_r.len = 0;
			break;
		}
	}
	return new_r;
}


large_integer lsum(large_integer u, large_integer v) {
	int k = 0;
	large_integer new_r;
	while (k < u.len && k < v.len) {
		new_r.digits[k] = u.digits[k] + v.digits[k];
		k++;
	}
	for (; k < u.len; k++) {
		new_r.digits[k] = u.digits[k];
	}
	for (; k < v.len; k++) {
		new_r.digits[k] = v.digits[k];
	}
	int carry = 0, i = 0;
	for (; i < k; i++) {
		int d = new_r.digits[i] + carry;
		new_r.digits[i] = d % BASE;
		carry = d / BASE;
	}
	if (carry > 0)
		new_r.digits[i++] = carry;
	new_r.len = i;
	new_r.sign = 0;
	return new_r;
}
large_integer lsub(large_integer u, large_integer v) {
	large_integer new_r;

	if (u.sign == v.sign) {
		if (u.sign == v.sign == -1) {
			new_r = ldiff(v, u);
			new_r.sign = v.sign;
		}
		else {
			new_r = ldiff(u, v);
			new_r.sign = u.sign;
		}
	}
	else {
		switch (compare_by_abs(u, v)) {
		case 1:
			new_r = ldiff(u, v);
			new_r.sign = u.sign;
			break;
		case -1:

			new_r = ldiff(v, u);
			new_r.sign = v.sign;
			break;
		case 0:

			new_r.sign = new_r.len = 0;
			break;
		}
	}
	int k = 0;
	for (int i = new_r.len - 1; i >= 0; i--) {
		if (new_r.digits[i] == 0)
			k++;
		else
			break;
	}
	new_r.len -= k;
	return new_r;
}



large_integer lmult(large_integer u, large_integer v) {
	large_integer new_r;
	new_r.sign = (u.sign == v.sign) ? u.sign : 1;
	new_r.len = u.len + v.len - 1;
	for (int i = 0; i < new_r.len; i++)
		new_r.digits[i] = 0;
	for (int i = 0; i < v.len; i++)
		for (int j = i; j < i + u.len; j++)
			new_r.digits[j] += v.digits[i] * u.digits[j];
	int carry = 0, i = 0;
	for (; i < new_r.len; i++) {
		int d = new_r.digits[i] + carry;
		new_r.digits[i] = d % BASE;
		carry = d / BASE;
	}
	if (carry > 0)
		new_r.digits[i++] = carry;
	new_r.len = i;
	return new_r;
}


large_integer ldiff(large_integer u, large_integer v){
	int k = 0;
	large_integer new_r;
	while (k < u.len && k < v.len) {
		new_r.digits[k] = u.digits[k] - v.digits[k];
		k++;
	}
	for (; k < u.len; k++) {
		new_r.digits[k] = u.digits[k];
	}
	int borrow = 0, i = 0;
	for (; i < k; i++) {
		int d = new_r.digits[i] - borrow;
		new_r.digits[i] = (d >= 0) ? d : d + BASE;
		borrow = (d >= 0) ? 0 : 1;
	}
	while (i > 0 && new_r.digits[i - 1] == 0) {
		i--;
	}
	new_r.len = i;
	new_r.sign = u.sign;
	return new_r;
}


int compare_by_abs(large_integer u, large_integer v) {
	if (u.len > v.len)
		return 1;
	else if (u.len < v.len)
		return -1;
	else {
		for (int i = u.len - 1; i >= 0; i--) {
			if (u.digits[i] > v.digits[i])
				return 1;
			else if (u.digits[i] < v.digits[i])
				return -1;
		}
		return 0;
	}
}

large_integer prod2(large_integer u, large_integer v) {
	ccnt++;
	large_integer x, y, w, z, r, p, q, t1, t2, t3, t4, t5;
	int n, m;

	n = (u.len > v.len) ? u.len : v.len;
	if (u.len == 0 || v.len == 0) {
		r.sign = r.len = 0;
		return r;
	}
	else if (n <= threshold) {
		r = lmult(u, v);
		return r;
	}
	else {
		m = n / 2;

		x = div_by_exp(u, m);//10�� m�°� �������� ��
		y = rem_by_exp(u, m);//������
		w = div_by_exp(v, m);//10�� m�°� �������� ��
		z = rem_by_exp(v, m);//������

		r = prod2(ladd(x, y), ladd(w, z));//(x+y)(w+x)-> prod2������ ���.
		p = prod2(x, w);
		q = prod2(y, z);

		t2 = pow_by_exp(p, 2 * m);//p*10�� 2m��
		t1 = lsub(r, p);//t1,t3�� (r-p-q)
		t3 = lsub(t1, q);
		t4 = pow_by_exp(t3, m);//(r-p-q)*10��m��
		t5 = ladd(t2, t4);//�ΰ� ���ϰ�
		return ladd(t5, q);//�������� +q�� ���� ����.
	}
}

large_integer pow_by_exp(large_integer u, int m) {
	large_integer new_v;
	new_v.sign = u.sign;
	new_v.len = u.len + m;
	for (int i = 0; i < m; i++) {
		new_v.digits[i] = 0;
	}
	for (int i = 0; i < u.len; i++) {
		new_v.digits[m + i] = u.digits[i];
	}
	return new_v;
}

large_integer div_by_exp(large_integer u, int m) {
	large_integer new_v;
	new_v.sign = u.sign;
	new_v.len = u.len - m;
	for (int i = 0; i < u.len; i++) {
		new_v.digits[i] = u.digits[m + i];
	}
	return new_v;
}

large_integer rem_by_exp(large_integer u, int m) {
	large_integer new_v;
	int k = 0;
	new_v.sign = u.sign;
	new_v.len = m;
	for (int i = 0; i <= m; i++) {
		new_v.digits[i] = u.digits[i];
	}
	for (int i = new_v.len - 1; i >= 0; i--) {
		if (u.digits[i] == 0)
			k++;
		else
			break;
	}
	new_v.len -= k;
	return new_v;
}*/

