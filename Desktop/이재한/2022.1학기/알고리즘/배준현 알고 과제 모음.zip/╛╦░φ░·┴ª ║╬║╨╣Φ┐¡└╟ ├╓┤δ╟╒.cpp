/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#include <map>
#define MAX 100

using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

int calculate(vector<int> arr);
int dp_arr[MAX];
vector<int> subsets;
int n;
vector<int> s;
vector<int> final_subsets;
int sum_of_number;
int cnt = 0;
int main() {
	cin >> n;
	int k;
	for (int i = 0; i < n; i++) {
		cin >> k;
		s.push_back(k);
	}
	sum_of_number = calculate(s);
	//cout << sum_of_number << endl; //�� �߳������� Ȯ��!
	
	if (sum_of_number <= 0) {
		cout << 0 << endl;
	}
	else {
		cout << sum_of_number << endl;
		for (int i = s.size() - 1; i >= 0; i--) {
			if (dp_arr[i] == sum_of_number) {
				for (int j = i; j >= 0; j--) {
					if (dp_arr[j] == s[j]) {
						final_subsets.push_back(dp_arr[j]);
						cnt = 1;
						break;
						
					}
					else {
						final_subsets.push_back(dp_arr[j] - dp_arr[j - 1]);
						
						
					}
				}
			}
			if (cnt == 1) {
				break;
			}
		}
	}

	for (int i = final_subsets.size() - 1; i >= 0; i--) {
		if (i == 0) {
			cout << final_subsets[i] << endl;
		}
		else {
			cout << final_subsets[i] << " ";
		}
	}
	
}

int calculate(vector<int> s) {
	int result = INT8_MIN;
	int size = s.size();
	//vector<int> dp_arr(size);

	dp_arr[0] = s[0];
	//subsets.push_back(s[0]);
	for (int i = 1; i < size; i++) {
		if (dp_arr[i - 1] + s[i] > s[i]) {
			dp_arr[i] = dp_arr[i - 1] + s[i];
			//subsets.push_back(s[i]);
		}
		else {
			dp_arr[i] = s[i];
			//subsets.clear();
			//subsets.push_back(s[i]);
		}
	}

	for (int i = 0; i < size; i++) {
		result = max(result, dp_arr[i]);
	}

	return result;
	
}*/