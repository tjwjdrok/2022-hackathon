/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#include <map>
#define MAX 9
#define INF 99

using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

typedef vector<int> ordered_set;
typedef struct node* node_pointer;
typedef struct node {
	int level;
	ordered_set path;
	int bound;
} nodetype;



int length(ordered_set path);
int bound(node_pointer v);
bool hasOutgoing(int v, ordered_set path);
bool hasIncoming(int v, ordered_set path);
bool isIn(int i, vector<int> A);
node_pointer create_node(int level);
void travel2(ordered_set& opttour, int& minlength);
int minlength;
ordered_set opttour;


struct compare {
	bool operator()(node_pointer p, node_pointer q) {
		if (p->bound < q->bound)
			return true;
		return false;
	}
};

priority_queue<node_pointer, vector<node_pointer>, compare> PQ;

int W[MAX][MAX];
int n, m, u, v;
int cnt = 0;

int main() {
	cin >> n;
	cin >> m;
	int num = 0;

	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			W[i][j] = INF;
		}
	}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			if (i == j) {
				W[i][j] = 0;
			}
		}
	}


	for (int i = 1; i <= m; i++) {
		cin >> u;
		cin >> v;
		cin >> num;
		W[u][v] = num;
	}

	travel2(opttour, minlength);

	for (int i = 0; i <= (opttour.size() - 1); i++) {
		if (i == (opttour.size() - 1)) {
			cout << opttour[i] << endl;
		}
		else {
			cout << opttour[i] << " ";
		}
	}

	cout << minlength << " ";
	cout << cnt << endl;



}

int length(ordered_set path) {
	vector<int>::iterator it;
	int len = 0;
	for (it = path.begin(); it != path.end(); it++)
		if (it != path.end() - 1)
			len += W[*it][*(it + 1)];
	return len;
}

int bound(node_pointer v) {
	// start from the length of path
	int lower = length(v->path);
	for (int i = 1; i <= n; i++) {
		if (hasOutgoing(i, v->path)) continue;
		int min = INF;
		for (int j = 1; j <= n; j++) {
			// Do not include self-loop
			if (i == j) continue;
			// Do not include an edge to which i cannot return
			if (j == 1 && i == v->path[v->path.size() - 1]) continue;
			// Do not include edges already in the path
			if (hasIncoming(j, v->path)) continue;
			// A lower bound (minimum) on the cost of leaving i
			if (min > W[i][j]) min = W[i][j];
		}
		lower += min;
	}
	return lower;
}

bool hasOutgoing(int v, ordered_set path) {
	vector<int>::iterator it;
	for (it = path.begin(); it != path.end() - 1; it++)
		if (*it == v) return true;
	return false;
}

bool hasIncoming(int v, ordered_set path) {
	vector<int>::iterator it;
	for (it = path.begin() + 1; it != path.end(); it++)
		if (*it == v) return true;
	return false;
}

void travel2(ordered_set& opttour, int& minlength) {
	priority_queue<node_pointer, vector<node_pointer>, compare> PQ;

	node_pointer u, v;
	minlength = INF;

	v = (node_pointer)malloc(sizeof(nodetype));
	if (v != NULL) {
		v->level = 0;
		v->path.push_back(1);
		v->bound = bound(v);
		PQ.push(v);
		cnt++;
	}
	while (!PQ.empty()) {
		v = PQ.top();
		PQ.pop();
		if (v->bound < minlength) {
			for (int i = 2; i <= n; i++) {
				// for all i such that i is not in v.path
				if (isIn(i, v->path)) continue;
				u = create_node(v->level + 1);
				u->path = v->path;
				u->path.push_back(i);
				if (u->level == n - 2) {
					for (int k = 2; k <= n; k++) {
						if (!isIn(k, u->path)) {
							u->path.push_back(k);
						}
					}
					u->path.push_back(1); // make first vertex last one
					if (length(u->path) < minlength) {
						minlength = length(u->path);;
						opttour.resize(u->path.size());
						copy(u->path.begin(), u->path.end(), opttour.begin());
					}
				}
				else {
					u->bound = bound(u);
					if (u->bound < minlength) {
						PQ.push(u);
						cnt++;
					}
						

				}
			}
		}
	}
}

bool isIn(int i, ordered_set A) {//A�� ���ϴ��� Ȯ��
	int k = 0;
	for (k = 0; k <= (A.size() - 1); k++) {
		if (i == A[k]) {
			return true;
		}
	}
	return false;
}

node_pointer create_node(int level) {
	node_pointer node = (node_pointer)malloc(sizeof(nodetype));
	if (node != NULL) {
		node->level = level;
		node->bound = bound(node);
	}
	return node;
}*/