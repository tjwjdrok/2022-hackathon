/*#include <iostream>
#include <vector>
#include <algorithm>
#define MAX 20
#define INF 1000000
//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

typedef struct node* node_pointer;
typedef struct node {
	int key;
	node_pointer left;
	node_pointer right;
} nodetype;

using namespace std;
int cnt_1 = 0;
int cnt_2 = 0;
void optsearchtree(int n, int p[], int& minavg, int R[][MAX]);
int minimum(int i, int j, int& minK, int M[][MAX], int d[MAX]);
node_pointer tree(int i, int j, int R[][MAX], int keys[MAX]);
void preorder(node_pointer root, int n);
void inorder(node_pointer root, int n);

int p[MAX];
int R[MAX][MAX];
int keys[MAX];

int main() {
	int n,minavg;
	cin >> n;

	for (int i = 1; i <= n; i++) {
		cin >> keys[i];
	}
	for (int i = 1; i <= n; i++) {
		cin >> p[i];
	}

	optsearchtree(n, p, minavg, R);

	for (int i = 1; i <= n; i++) {
		for (int j = i; j <= n; j++) {
			if (j == n) {
				cout << R[i][j];
			}
			else {
				cout << R[i][j] << " ";
			}
		}
		cout << endl;
	}
	node_pointer root = tree(1, n, R, keys);

	cout << "preorder : " << endl;
	preorder(root, n);

	cout << "inorder : " << endl;
	inorder(root, n);


}

void optsearchtree(int n, int p[], int& minavg, int R[][MAX]) {
	int i, j, k, diagonal;
	int A[MAX][MAX];
	for (i = 1; i <= n; i++) {
		A[i][i] = p[i];
		A[i][i - 1] = 0;
		R[i][i] = i;
		R[i][i - 1] = 0;
	}
	A[n + 1][n] = 0;
	R[n + 1][n] = 0;
	for (diagonal = 1; diagonal <= n - 1; diagonal++)
		for (i = 1; i <= n - diagonal; i++) {
			j = i + diagonal;
			A[i][j] = minimum(i, j, k, A, p);
			R[i][j] = k;
		}
	minavg = A[1][n];

	for (int i = 1; i <= n; i++) {
		for (int j = i; j <= n; j++) {
			if (j == n) {
				cout << A[i][j];
			}
			else {
				cout << A[i][j] << " ";
			}
		}
		cout << endl;
	}
}

int minimum(int i, int j, int& minK, int M[][MAX], int d[MAX]) {
	int minV = INF;
	int sum = 0;

	for (int k = i; k <= j ; k++) {
		sum = sum + p[k];
		int value = M[i][k - 1] + M[k + 1][j];
		if (minV > value) {
			minV = value;
			minK = k;
		}
	}
	return minV + sum;
}

node_pointer tree(int i, int j, int R[][MAX], int keys[MAX]) {
	int k;
	node_pointer p;
	k = R[i][j];
	if (k == 0)
		return NULL;
	else {
		p = (node_pointer)malloc(sizeof(nodetype));
		p->key = keys[k];
		p->left = tree(i, k - 1, R, keys);
		p->right = tree(k + 1, j, R, keys);
		return p;
	}
}

void preorder(node_pointer root, int n) {
	if (root != NULL) {
		if (cnt_1 == n - 1) {
			cout << root->key << endl;
		}
		else {
			cnt_1++;
			cout << root->key << " ";
			preorder(root->left, n);
			preorder(root->right, n);
		}
	}
}

void inorder(node_pointer root, int n) {
	if (root != NULL) {
		if (cnt_2 == n - 1) {
			cout << root->key << " ";//<< endl;
		}
		else {
			cnt_2++;
			inorder(root->left, n);
			cout << root->key << " ";
			inorder(root->right, n);
		}
	}
}*/

