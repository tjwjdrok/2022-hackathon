/*#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
	vector <unsigned long long int> a;
	int n = 0;
	int b = 0;
	unsigned long long int sum = 0;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> b;
		a.push_back(b);
	}

	sort(a.begin(), a.end());

	cout << a[1] << ' ';
	cout << a[n - 2] << ' ';
	
	sum = a[n - 2] + a[1];
	cout << sum << endl;
	return 0;
}*/