/*#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.


typedef struct sequence_of_integer {
	int job[16];
	int size;
}sequence_of_integer;


int is_feasible(vector<int> deadline, sequence_of_integer* K);
void insert(int position, int desti, sequence_of_integer* K);
void schedule(int n, vector<int> deadline, sequence_of_integer* J);
vector<int> deadline;
vector<int> profit;

int main() {
	int n;
	cin >> n;

	for (int i = 0; i < n; i++) {
		int a;
		cin >> a;
		deadline.push_back(a);
	}
	for (int i = 0; i < n; i++) {
		int a;
		cin >> a;
		profit.push_back(a);
	}

	//������������ �������ִ� �ڵ�
	int max;
	for (int i = 0; i < n; i++) {
		max = i;
		for (int j = i + 1; j < n; j++) {
			if (profit[max] < profit[j]) max = j;
		}
		if (i != max) {
			int temp;
			temp = deadline[i];
			deadline[i] = deadline[max];
			deadline[max] = temp;
			temp = profit[i];
			profit[i] = profit[max];
			profit[max] = temp;
		}
	}



	sequence_of_integer job;
	schedule(n, deadline, &job);
	int sum = 0;
	for (int i = 0; i < job.size; i++) {
		sum += profit[job.job[i]];
	}
	cout << sum << endl;



}


int is_feasible(vector<int> deadline, sequence_of_integer* K) {
	
	int it = 0;
	for (int i = 1; it < K->size; i++, it++) {
		if (i > deadline[K->job[it]]) {
			return 0;
		}
	}
	return 1;
}

void schedule(int n, vector<int> deadline, sequence_of_integer *J) {
	int i,it;
	sequence_of_integer K;
	J->job[0] = 0;
	J->size = 1;

	for (i = 1; i < n; i++) {
		K.size = J->size;
		for (int t = 0; t < J->size; t++) {
			K.job[t] = J->job[t];
		}
		it = J->size - 1;
		while (deadline[K.job[it]] <= deadline[i]) {
			it++;
			if (it >= K.size) break;
		}
		if (it >= K.size) K.job[K.size++] = i;
		else insert(it, i, &K);

		if (is_feasible(deadline, &K)) {
			J->size = K.size;
			for (int t = 0; t < K.size; t++) {
				J->job[t] = K.job[t];
			}
		}
	}
	
}

void insert(int position, int desti, sequence_of_integer* K) {
	for (int i = K->size; i > position; i--) {
		K->job[i] = K->job[i - 1];
	}
	K->job[position] = desti;
	K->size++;
}*/