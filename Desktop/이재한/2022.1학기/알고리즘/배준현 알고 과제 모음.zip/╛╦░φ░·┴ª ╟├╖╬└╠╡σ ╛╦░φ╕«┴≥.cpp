/*#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
#define MAX 128
#define INF 1000000

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

int W[MAX][MAX];
int D[MAX][MAX];
int P[MAX][MAX];
//int path_length = 0;
void floyd2(int n,  int D[][MAX], int P[][MAX]);
void path(int q, int r);
void init(int N);


int main() {
	int N,M,T;
	int u, v, w;

	cin >> N;
	cin >> M;
	init(N);


	for (int i = 0; i < M; i++) {
		cin >> u;
		cin >> v;
		cin >> w;
		W[u][v] = w;
	}

	floyd2(N, D, P);

	for (int i = 1; i <= N; i++) {
		for (int j = 1; j <= N; j++) {
			if (D[i][j] == INF) {
				printf("INF ");
				//cout << "INF" << " ";
			}
			else {
				printf("%d ", D[i][j]);
				//cout << D[i][j] << " ";
			}
		}
		printf("\n");
		//cout << endl;
	}
	for (int i = 1; i <= N; i++) {
		for (int j = 1; j <= N; j++) {
			printf("%d ", P[i][j]);
		}
		printf("\n");
		//cout << endl;
	}


	cin >> T;
	int q, r;
	for (int i = 0; i < T; i++) {
		//path_length = 0;
		cin >> q;
		cin >> r;
		printf("%d ", q);
		//cout << q << " ";
		path(q, r);
		printf("%d ", r);
		//cout << r << " ";
		if (D[q][r] == INF) {
			cout << "INF" << " " << endl;
		}
		else {
			cout << D[q][r] << " " << endl;
		}
	}
}


void floyd2(int n, int D[][MAX], int P[][MAX]) {
	int i, j, k;
	for (i = 1; i <= n; i++)
		for (j = 1; j <= n; j++) {
			P[i][j] = 0;
			D[i][j] = W[i][j];
		}
	
	for (k = 1; k <= n; k++)
		for (i = 1; i <= n; i++)
			for (j = 1; j <= n; j++)
				if (D[i][k] + D[k][j] < D[i][j]) {
					P[i][j] = k;
					D[i][j] = D[i][k] + D[k][j];
				}
}

void path(int q, int r ) {

	if (P[q][r] != 0) {
		path(q, P[q][r]);
		printf("%d ", P[q][r]);
		//cout << P[q][r] << " ";
		path(P[q][r], r);
	}
	//else {
		//path_length = path_length + D[q][r];
	//}
}

void init(int N) {
	for (int i = 1; i <= N; i++) {
		for (int j = 1; j <= N; j++) {
			if (i == j) {
				W[i][j] = 0;
			}
			else {
				W[i][j] = INF;
			}
			
		}
	}

}*/