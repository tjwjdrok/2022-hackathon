/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#include <map>
#define MAX 20

using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.


int selection(int low, int high, int k);
void partition(int low, int high, int& pivotpoint);

int n,T,k;
int S[MAX];
int new_S[MAX];
int cnt = 0;

int main() {
	cin >> n;

	for (int i = 1; i <= n; i++) {
		cin >> S[i];
	}

	cin >> T;

	for (int i = 1; i <= T; i++) {
		cin >> k;
		for (int j = 1; j <= n; j++) {
			new_S[j] = S[j];
		}
		cout<<selection(1, n, k)<<" ";
		cout << cnt << endl;
		cnt = 0;
	}

}

int selection(int low, int high, int k) {
	int pivotpoint;
	if (low == high)
		return new_S[low];
	else {
		partition(low, high, pivotpoint);
		if (k == pivotpoint)
			return new_S[pivotpoint];
		else if (k < pivotpoint)
			return selection(low, pivotpoint - 1, k);
		else // k > pivotpoint
			return selection(pivotpoint + 1, high, k);
	}
}

void partition(int low, int high, int& pivotpoint) {
	cnt++;
	int i, j, pivotitem;
	pivotitem = new_S[low];
	j = low;
	for (i = low + 1; i <= high; i++)
		if (new_S[i] < pivotitem) {
			j++;
			// exchange S[i] and S[j]
			int t = new_S[i]; 
			new_S[i] = new_S[j]; 
			new_S[j] = t; 
		}
	pivotpoint = j;
	// exchange S[low] and S[pivotpoint]
	int t = new_S[low]; 
	new_S[low] = new_S[pivotpoint];
	new_S[pivotpoint] = t; 
	//for (int i = 1; i <= n; i++) {//partition�ѹ������� ���
		//cout << new_S[i] << " ";
	//}
	//cout << endl;
}*/