/*#include <iostream>
#include <vector>
#include <algorithm>


#define MAX 20
#define INF 100000


using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.



typedef struct edge* edge_pointer;

typedef struct edge {
	int u;
	int v;
	int weight;
} edgetype;

typedef vector<edge_pointer> set_of_edges;

void dijkstra(int n, int W[][MAX], set_of_edges& F, int touch[MAX], int length[MAX]);

int main() {
	int N, M, a, b, cost;
	set_of_edges F;
	int W[MAX][MAX];
	int touch[MAX];
	int length[MAX];
	cin >> N;
	cin >> M;

	for (int i = 1; i <= N; i++) {
		for (int j = 1; j <= N; j++) {
			if (i == j) {
				W[i][j] = 0;
			}
			else {
				W[i][j] = INF;
			}
		}
	}

	for (int i = 0; i < M; i++) {
		cin >> a;
		cin >> b;
		cin >> cost;
		W[a][b] = cost;
	}

	dijkstra(N, W, F, touch, length);

	for (int i = 0; i < N - 1; i++) {
		cout << F[i]->u << " ";
		cout << F[i]->v << " ";
		cout << F[i]->weight;
		cout << endl;
	}

}

void dijkstra(int n, int W[][MAX], set_of_edges& F, int touch[MAX], int length[MAX]) {
	int i, vnear, min;
	edge_pointer e;
	F.clear(); 
	for (i = 2; i <= n; i++) {
		touch[i] = 1;
		length[i] = W[1][i];
	}
	for (int k = 1; k < n;k++) {
		min = INF;
		for (i = 2; i <= n; i++)
			if (0 <= length[i] && length[i] < min) {
				min = length[i];
				vnear = i;
			}
		e = (edge_pointer)malloc(sizeof(edgetype));
		if (e != NULL) {
			e->u = touch[vnear];
			e->v = vnear;
			e->weight = W[touch[vnear]][vnear];
			F.push_back(e);//touch��忡�� ������ ����ġ ����.
		}
		for (i = 2; i <= n; i++)//touch�� length�� �ٲٴ� ����.
			if (length[vnear] + W[vnear][i] < length[i]) {
				length[i] = length[vnear] + W[vnear][i];
				touch[i] = vnear;
			}
		length[vnear] = -1;
		for (int i = 2; i <= n; i++) {
			if (i == n) {
				cout << touch[i];
			}
			else {
				cout << touch[i] << " ";
			}

		}
		cout << endl;
		for (int i = 2; i <= n; i++) {
			if (i == n) {
				if (length[i] >= INF) {
					cout << "INF";
				}
				else {
					cout << length[i];
				}
			}

			else if (length[i] >= INF) {
				cout << "INF" << " ";
			}
			else {
				cout << length[i] << " ";
			}
		}
		cout << endl;
	}
}*/

