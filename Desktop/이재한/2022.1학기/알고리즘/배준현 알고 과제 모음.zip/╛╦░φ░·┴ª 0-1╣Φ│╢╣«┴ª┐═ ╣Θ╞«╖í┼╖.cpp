/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#include <map>
#define MAX 256
#define TRUE 1
#define FALSE 0


using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

using namespace std;

bool promising(int i, int profit, int weight);
void knapsack4(int i, int profit, int weight);

int w[MAX], p[MAX], n, W, maxprofit = 0;
int include[MAX], bestset[MAX];
float maxbound = 0;
float ansbound = 0;

int main() {
    int i, T;

    cin >> n;

    for (i = 1; i <= n; i++)
        cin >> w[i];
    for (i = 1; i <= n; i++)
        cin >> p[i];

    for (i = 1; i <= n; i++)
        for (int j = i; j <= n; j++)
            if (p[i] / w[i] < p[j] / w[j]) {
                swap(p[i], p[j]);
                swap(w[i], w[j]);
            }

    cin >> T;

    for (i = 0; i < T; i++) {
        int maxweight = 0;
        cin >> W;
        maxprofit = 0;
        maxbound = 0;
        ansbound = 0;
        knapsack4(0, 0, 0);
        for (int i = 1; i <= n; i++)
            if (bestset[i])
                maxweight += w[i];
        cout << maxprofit << " " << maxweight << " " << ansbound << endl;
    }

    return 0;
}

bool promising(int i, int profit, int weight) {
    int j, k, totweight;
    float bound;

    if (weight >= W)
        return false;
    else {
        j = i + 1;
        bound = profit;
        totweight = weight;
        while (j <= n && totweight + w[j] <= W) {
            totweight += w[j];
            bound += p[j];
            j++;
        }
        k = j;
        if (k <= n)
            bound += (W - totweight) * ((float)p[k] / w[k]);

        maxbound = bound;

        return bound > maxprofit;
    }
}

void knapsack4(int i, int profit, int weight) {
    if (weight <= W && profit > maxprofit) {
        maxprofit = profit;
        copy(include, include + n + 1, bestset);
        ansbound = maxbound;
    }
    if (promising(i, profit, weight)) {
        include[i + 1] = TRUE;
        knapsack4(i + 1, profit + p[i + 1], weight + w[i + 1]);
        include[i + 1] = FALSE;
        knapsack4(i + 1, profit, weight);
    }
}*/