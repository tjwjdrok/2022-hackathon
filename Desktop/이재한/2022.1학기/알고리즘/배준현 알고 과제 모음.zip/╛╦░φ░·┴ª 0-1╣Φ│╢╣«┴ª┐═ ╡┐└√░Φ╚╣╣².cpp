/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#include <map>
#define MAX 256
using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.

int w[MAX];
int p[MAX];
int P[MAX][MAX];
int W;

void knapsack2(int n, int W, int w[], int p[], int P[][MAX]);

int main() {
	int n,T;
	cin >> n;

	for (int i = 1; i <= n; i++) {
		cin >> w[i];
	}
	for (int i = 1; i <= n; i++) {
		cin >> p[i];
	}
	cin >> T;

	for (int i = 1; i <= T; i++) {
		cin >> W;
		knapsack2(n, W, w, p, P);
	}

}

void knapsack2(int n, int W, int w[], int p[], int P[][MAX]) {
	for (int i = 0; i <= n; i++)
		P[i][0] = 0;
	for (int j = 0; j <= W; j++)
		P[0][j] = 0;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= W; j++) {
			P[i][j] = (w[i] > j) ? P[i - 1][j] : max(P[i - 1][j], p[i] + P[i - 1][j - w[i]]);
		}
			
	}
	cout << P[n][W] << " " << P[n - 1][W] << " " << P[n - 1][W - w[n]] << endl;
	//for (int i = 0; i <= n; i++) { //P�迭 ����ϴ� �ڵ�
		//for (int j = 0; j <= W; j++) {
			//cout << P[i][j] << " ";
		//}
		//cout << endl;
	//}
}*/