/*#include <iostream>
#include <vector>
#include <algorithm>


#define MAX 20


using namespace std;
typedef int set_pointer;

void initial(int n);
set_pointer find(int i);

typedef struct edge* edge_pointer;

typedef struct edge {
	int u;
	int v;
	int weight;
} edgetype;

typedef vector<edge_pointer> set_of_edges;
bool equal(set_pointer p, set_pointer q);
void merge(set_pointer p, set_pointer q);
void kruskal(int n, int m, set_of_edges E, set_of_edges& F);
void compare(set_of_edges E, int m);

int U[MAX];

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.


int main() {
	int n, m,a,b,cost;
	set_of_edges E;
	set_of_edges F;
	cin >> n;
	cin >> m;
	edge_pointer temp;
	
	for (int i = 0; i < m; i++) {
		cin >> a;
		cin >> b;
		cin >> cost;
		temp = (edge_pointer)malloc(sizeof(edgetype));
		if (temp != NULL) {
			temp->u = a;
			temp->v = b;
			temp->weight = cost;
			E.push_back(temp);
		}
	}

	kruskal(n, m, E, F);

	for (int i = 0; i < n - 1; i++) {
		cout << F[i]->u << " ";
		cout << F[i]->v << " ";
		cout << F[i]->weight;
		cout << endl;
	}

	//for (int i = 0; i < m; i++) {
	//	cout << E[i]->weight << endl;
	//}
}

void initial(int n) {
	for (int i = 1; i <= n; i++)
		U[i] = i;
}

set_pointer find(int i) {
	int j = i;
	while (U[j] != j)
		j = U[j];
	return j;
}

bool equal(set_pointer p, set_pointer q) {
	return (p == q) ? true : false;
}

void merge(set_pointer p, set_pointer q) {
	if (p < q)
		U[q] = p;
	else
		U[p] = q;
}

void kruskal(int n, int m, set_of_edges E, set_of_edges& F) {
	set_pointer p, q;
	vector<edge_pointer>::iterator iter = E.begin();
	
	compare(E,m);
	F.clear(); 
	initial(n);
	while (F.size() < n - 1) {
		edge_pointer e = *iter++;
		p = find(e->u);
		q = find(e->v);
		if (!equal(p, q)) {
			merge(p, q);
			F.push_back(e);
		}
	}
}

void compare(set_of_edges E, int m) {
	edge_pointer tmp;
	tmp = (edge_pointer)malloc(sizeof(edgetype));
	for (int i = 0; i < m-1; i++) {
		for (int j = i + 1; j < m; j++) {
			if (E[i]->weight > E[j]->weight) {
				tmp->u = E[i]->u;
				tmp->v = E[i]->v;
				tmp->weight = E[i]->weight;
				E[i]->u = E[j]->u;
				E[i]->v = E[j]->v;
				E[i]->weight = E[j]->weight;
				E[j]->u = tmp->u;
				E[j]->v = tmp->v;
				E[j]->weight = tmp->weight;
			}
			else if (E[i]->weight == E[j]->weight) {
				if (E[i]->u > E[j]->u) {
					tmp->u = E[i]->u;
					tmp->v = E[i]->v;
					tmp->weight = E[i]->weight;
					E[i]->u = E[j]->u;
					E[i]->v = E[j]->v;
					E[i]->weight = E[j]->weight;
					E[j]->u = tmp->u;
					E[j]->v = tmp->v;
					E[j]->weight = tmp->weight;
				}

			}
		}
	}
}*/

