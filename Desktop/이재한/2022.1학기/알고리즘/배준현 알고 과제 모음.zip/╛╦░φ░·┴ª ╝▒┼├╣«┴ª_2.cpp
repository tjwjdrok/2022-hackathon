/*#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <queue>
#include <stdlib.h>
#include <map>
#define MAX 100

using namespace std;

//[2018111886] [��â��] ���� �� �ҽ� �ڵ带 �ٸ� �ҽ� �ڵ带 �������� �ʰ� ���� �ۼ��Ͽ����ϴ�.


int n, T, k;
int S[MAX];
int new_S[MAX];
int cnt = 0;
int mediannum[MAX];
int select(int n, int S[MAX], int k);
int selection2(int S[MAX], int low, int high, int k);
void partition2(int S[MAX], int low, int high, int& pivotpoint);
int median(int S[MAX], int first, int last);
int id = 0;

int main() {
	cin >> n;

	for (int i = 1; i <= n; i++) {
		cin >> S[i];
	}

	cin >> T;

	for (int i = 1; i <= T; i++) {
		cin >> k;
		for (int j = 1; j <= n; j++) {
			new_S[j] = S[j];
		}
		cout << select(n, new_S, k) << " ";
		cout << cnt << endl;
		cnt = 0;
	}

	
}

int select(int n, int S[MAX], int k) {
	return selection2(S, 1, n, k);
}

int selection2(int S[MAX], int low, int high, int k) {
	int pivotpoint;
	if (low == high)
		return S[low];
	else {
		partition2(S, low, high, pivotpoint);
		if (k == pivotpoint)
			return S[pivotpoint];
		else if (k < pivotpoint)
			return selection2(S, low, pivotpoint - 1, k);
		else // k > pivotpoint
			return selection2(S, pivotpoint + 1, high, k);
	}
}

void partition2(int S[MAX], int low, int high, int& pivotpoint) {
	cnt++;
	int arraysize = high - low + 1;
	int r = (int)ceil((double)arraysize / 5);
	int i, j, mark, first, last, pivotitem, T[MAX];
	for (i = 1; i <= r; i++) { // Prepare for the medians//5���� �ɰ��� �� �ȿ��� median���� �����ϴºκ�
		first = low + 5 * i - 5;
		last = min(low + 5 * i - 1, low + arraysize - 1);
		T[i] = median(S, first, last);
		cout << T[i] << " ";
	}
	pivotitem = select(r, T, (r + 1) / 2); // the median of medians
	j = low;
	for (i = low; i <= high; i++)
		if (S[i] == pivotitem) {
			swap(S[i], S[j]);
			mark = j++;
		}
		else if (S[i] < pivotitem)
			swap(S[i], S[j++]);
	pivotpoint = j - 1;
	swap(S[mark], S[pivotpoint]);

	//for (int i = 1; i <= n; i++) {//partition�ѹ� �������� ���
		//cout << S[i] << " ";
	//}
	//cout << endl;

}

int median(int S[MAX], int first, int last) {
	int arr[MAX] = { 0, };
	
	int midnum = 0;
	for (int i = first; i <= last; i++) {
		arr[i] = S[i];
	}
	sort(arr + first, arr +last+1);
	midnum = arr[(int)((double)(first+last) / 2)];
	return midnum;
	
}*/
